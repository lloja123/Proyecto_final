conn = new Mongo();
db = conn.getDB("trabajo_final");

db.productos.insert(
  [
   {nombre: 'Laptop', precio:'460', color:'Negro', marca: 'Acer'}
   
 ]);

db.ventas.insert(
  [
   {producto: 'Pantalon', fechacompra:'27/12/2022', precio:'60', cantidad:'2', 
    estado: 'Pagado', preciototal: '120'}
]);

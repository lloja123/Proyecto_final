var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var VentaSchema = new Schema({
    producto: {type: String, required: true, max: 20},
    fechacompra: {type: String, required: true, max: 20},
    precio: {type: String, required: true, max: 20},
    cantidad: {type: String, required: true},
    estado: {type: String, required: true, max:20},
    preciototal: {type: String, required: true, max:20}
});

module.exports = mongoose.model('Venta', VentaSchema);

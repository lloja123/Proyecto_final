var express = require('express');
var router = express.Router();

var venta = require('../controllers/VentaController.js');

router.get('/', venta.list);
router.get('/show/:id',venta.show);
router.get('/create',venta.create);
router.post('/save', venta.save);
router.get('/edit/:id', venta.edit);
router.post('/update/:id',venta.update);
router.post('/delete/:id',venta.delete);

module.exports = router;

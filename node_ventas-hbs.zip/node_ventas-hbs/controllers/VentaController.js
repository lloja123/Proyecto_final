var mongoose = require('mongoose');
var Venta = require("../models/Venta");

var ventaController = {};

ventaController .list = function(req, res){
    
    Venta.find({}).exec(function(err, ventas){
        if( err ){ console.log('Error: ', err); return; }
        console.log("The INDEX");
        res.render('../views/venta/index', {ventas: ventas,titulo:'INDEX'} );
        
    });
    
};

ventaController.show = function(req, res){
    Venta.findOne({_id: req.params.id}).exec(function(err, venta){
        if( err ){ console.log('Error: ', err); return; }
        
        res.render('../views/venta/show', {venta: venta} );
    });
    
};

ventaController.create = function(req, res){
    res.render('../views/venta/create');
};

ventaController.save = function(req, res){
    var venta= new Venta( req.body );
    
    venta.save(function(err){
        if( err ){ console.log('Error: ', err); return; }
        
        console.log("Successfully created a venta. :)");
        res.redirect("/ventas/show/"+venta._id);
        //res.redirect("/ventass");
    });
};

ventaController.edit = function(req, res) {
  Venta.findOne({_id: req.params.id}).exec(function (err, venta) {
    if (err) { console.log("Error:", err); return; }
    
    res.render("../views/venta/edit", {venta: venta});
    
  });
};

ventaController.update = function(req, res){
    Venta.findByIdAndUpdate( req.params.id, {$set: {
        producto: req.body.producto,
        fechacompra: req.body.fechacompra,
        precio: req.body.precio,
        cantidad: req.body.cantidad,
        estado: req.body.estado,
        preciototal: req.body.preciototal,
    }}, { new: true },
    function( err, venta){
        if( err ){ 
            console.log('Error: ', err); 
            res.render('../views/venta/edit', {venta: req.body} );
        }
        
        console.log( venta );
        
        res.redirect('/ventas/show/' + venta._id);
        
    });
};
ventaController.delete = function(req, res){
    
    Venta.remove({_id: req.params.id}, function(err){
        if( err ){ console.log('Error: ', err); return; }
        
        console.log("Venta deleted!");
        res.redirect("/ventas");
    });
    
};

module.exports = ventaController;
